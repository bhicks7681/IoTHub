


namespace Balloon.Functions
{
    public class IoTMessage
    {

        public double lat { get; set; }
        public double lon { get; set; }
        public double initial_alt { get; set; }
        public double hour { get; set; }
        public double min { get; set; }
        public double second { get; set; }
        public double day { get; set; }
        public double month { get; set; }
        public double year { get; set; }
        public double ascent { get; set; }
        public double drag { get; set; }
        public double burst { get; set; }

    }
}