using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Net.Http;
using System.Text;
using Microsoft.Azure.Devices.Client;
using System.Net;

namespace Balloon.Functions
{
    public static class PredictionC2C
    {
        
        private static DeviceClient s_deviceClient;

        [FunctionName("PredictionC2C")]
        public static async Task<HttpResponseMessage> Run(
            [HttpTrigger(AuthorizationLevel.Admin, "get", "post", Route = null)] HttpRequestMessage req,
            ILogger log, PredictionMessage prediction)
        {
            
            var messageString = JsonConvert.SerializeObject(prediction);
            var message = new Message(Encoding.ASCII.GetBytes(messageString));

            // Add a custom application property to the message.
            // An IoT hub can filter on these properties without access to the message body.

            // Send the telemetry message
            await s_deviceClient.SendEventAsync(message);
            return req.CreateResponse(HttpStatusCode.OK);
        }
    }
}
