using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Azure.EventHubs;
using System.Text;
using System.Net.Http;
using System.Threading;
using System.Collections.Generic;
using System.Web;
using Microsoft.Azure.Devices.Client;
using System.Net;

namespace Balloon.Functions
{
    public static class HabHubPost
    {
        private static HttpClient client = new HttpClient();      

        [FunctionName("HabHubPost")]
        public static async Task<HttpResponseMessage> Run(
            [HttpTrigger(AuthorizationLevel.Admin, "post", "get", Route = null)] HttpRequestMessage req,
            ILogger log, FormUrlEncodedContent content)
        {
            var badRequest = req.CreateResponse(HttpStatusCode.BadRequest);

            var response = await client.PostAsync("http://predict.habhub.org/ajax.php", content);

            if (response.IsSuccessStatusCode)
            {
                var responseString = await response.Content.ReadAsStringAsync();


                var predictionResponse = JsonConvert.DeserializeObject<HabHubPredictionResponse>(responseString);

                // example request: http://predict.habhub.org/ajax.php?action=getCSV&uuid=202f57505788f22612beb5093b66ff53c60a43b5

                var builder = new UriBuilder("http://predict.habhub.org/ajax.php");
                builder.Port = -1;
                var query = HttpUtility.ParseQueryString(builder.Query);
                query["action"] = "getCSV";
                query["uuid"] = predictionResponse.uuid;
                builder.Query = query.ToString();
                string url = builder.ToString();


                response = await client.GetAsync(url);

                if (response.IsSuccessStatusCode)
                {
                    responseString = await response.Content.ReadAsStringAsync();

                    var csv = new CsvHelper.CsvReader(new StringReader(responseString));

                    csv.Read();

                    var records = new List<HabHubPredictionPoint>(csv.GetRecords<HabHubPredictionPoint>());
                    
                    return req.CreateResponse(HttpStatusCode.OK,records);
                }
                else
                    return badRequest;
            }
            else
                return badRequest;




        }
    }
}

