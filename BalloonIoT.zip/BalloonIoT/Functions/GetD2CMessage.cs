using IoTHubTrigger = Microsoft.Azure.WebJobs.EventHubTriggerAttribute;

using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Azure.EventHubs;
using System.Text;
using System.Net.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Generic;
using System;
using System.Web;
using System.IO;
using Microsoft.Azure.Devices.Client;

namespace Balloon.Functions
{
    public static class ProcessD2CMessage
    {
        private static HttpClient client = new HttpClient();

        [FunctionName("ProcessD2CMessage")]
        public static async Task Run([IoTHubTrigger("messages/events", Connection = "IoTConn")]EventData message, ILogger log, DurableOrchestrationContext context)
        {
            var receivedIoT = JsonConvert.DeserializeObject<IoTMessage>(Encoding.UTF8.GetString(message.Body.Array));


            var postValues = new Dictionary<string, string>
            {
                { "action","submitForm"},
                { "lat",  receivedIoT.lat.ToString()},
                { "lon",  receivedIoT.lon.ToString()},
                { "initial_alt", receivedIoT.initial_alt.ToString()},
                { "hour", receivedIoT.hour.ToString()},
                { "min", receivedIoT.min.ToString()},
                { "second", receivedIoT.second.ToString()},
                { "day", receivedIoT.day.ToString()},
                { "month", receivedIoT.month.ToString()},
                { "year", receivedIoT.year.ToString()},
                { "ascent", receivedIoT.ascent.ToString()},
                { "drag", receivedIoT.drag.ToString()},
                { "burst", receivedIoT.burst.ToString()},
                { "submit", "Run Prediction"}
            };

            //Get List of Prediction Points from Habhub

            var content = new FormUrlEncodedContent(postValues);
            var returnContent = new List<HabHubPredictionPoint>();
            returnContent = await context.CallActivityAsync<List<HabHubPredictionPoint>>("HabHubPost", content);

            //If points are received Post Prediction Points back to IoTHub

            if (returnContent.Count >= 2)
            {
                var landingRecord = returnContent[returnContent.Count - 2];

                var predictionMessage = new PredictionMessage();

                predictionMessage.PredictionDate = DateTime.UtcNow;

                predictionMessage.LandingDateTime = UnixTime.UnixTimeToDateTime(landingRecord.Timestamp);
                predictionMessage.LandingLat = landingRecord.Latitude;
                predictionMessage.LandingLong = landingRecord.Longitude;
                await context.CallActivityAsync("PredictionC2C", predictionMessage);

            }

        }
    }
}